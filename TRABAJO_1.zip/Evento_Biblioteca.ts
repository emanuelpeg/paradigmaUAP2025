public class EventoBiblioteca {
    private String nombre;
    private String fecha;

    public EventoBiblioteca(String nombre, String fecha) {
        this.nombre = nombre;
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Evento: " + nombre + " el " + fecha;
    }
}
