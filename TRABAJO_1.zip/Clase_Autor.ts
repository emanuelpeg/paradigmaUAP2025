public class Autor {
    private String nombre;
    private String biografia;
    private int anioNacimiento;

    public Autor(String nombre, String biografia, int anioNacimiento) {
        this.nombre = nombre;
        this.biografia = biografia;
        this.anioNacimiento = anioNacimiento;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre + " (" + anioNacimiento + ")";
    }
}
