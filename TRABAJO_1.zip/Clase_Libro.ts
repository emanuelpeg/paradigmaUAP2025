import java.util.LinkedList;
import java.util.Queue;

public class Libro {
    private String titulo;
    private String isbn;
    private Autor autor;
    private boolean disponible = true;
    private Queue<Socio> reservas = new LinkedList<>();

    public Libro(String titulo, String isbn, Autor autor) {
        this.titulo = titulo;
        this.isbn = isbn;
        this.autor = autor;
    }

    public boolean estaDisponible() {
        return disponible;
    }

    public void prestar() {
        disponible = false;
    }

    public void devolver() {
        disponible = true;
    }

    public void reservar(Socio socio) {
        reservas.add(socio);
    }

    public Socio siguienteReserva() {
        return reservas.poll();
    }

    public String getTitulo() {
        return titulo;
    }

    public Autor getAutor() {
        return autor;
    }

    @Override
    public String toString() {
        return titulo + " - " + autor;
    }
}
