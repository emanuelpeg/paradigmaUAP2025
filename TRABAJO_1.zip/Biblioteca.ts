import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Libro> libros = new ArrayList<>();
    private List<Socio> socios = new ArrayList<>();
    private List<EventoBiblioteca> eventos = new ArrayList<>();

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public void agregarSocio(Socio socio) {
        socios.add(socio);
    }

    public void prestarLibro(String titulo, Socio socio) {
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                if (libro.estaDisponible() && socio.puedePrestar()) {
                    libro.prestar();
                    socio.prestarLibro(libro);
                    System.out.println(socio.getNombre() + " prestó " + titulo);
                } else {
                    libro.reservar(socio);
                    System.out.println(socio.getNombre() + " reservó " + titulo);
                }
            }
        }
    }

    public void devolverLibro(String titulo, Socio socio, int diasRetraso) {
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                libro.devolver();
                socio.devolverLibro(libro, diasRetraso);
                Socio siguiente = libro.siguienteReserva();
                if (siguiente != null) {
                    System.out.println("Aviso: " + siguiente.getNombre() + " puede retirar " + titulo);
                }
            }
        }
    }

    public void agregarEvento(EventoBiblioteca evento) {
        eventos.add(evento);
    }

    public void mostrarEventos() {
        for (EventoBiblioteca e : eventos) {
            System.out.println(e);
        }
    }

    public void recomendarLibros(Socio socio) {
        if (socio.getHistorial().isEmpty()) {
            System.out.println("No hay recomendaciones para " + socio.getNombre());
            return;
        }
        Libro ultimo = socio.getHistorial().get(socio.getHistorial().size() - 1);
        System.out.println("Recomendaciones para " + socio.getNombre() + ":");
        for (Libro l : libros) {
            if (l.getAutor().getNombre().equals(ultimo.getAutor().getNombre()) && !socio.getHistorial().contains(l)) {
                System.out.println(" - " + l);
            }
        }
    }
}
