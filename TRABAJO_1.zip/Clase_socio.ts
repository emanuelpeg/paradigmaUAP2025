import java.util.ArrayList;
import java.util.List;

public class Socio {
    private String nombre;
    private List<Libro> librosPrestados = new ArrayList<>();
    private double multa = 0;
    private List<Libro> historial = new ArrayList<>();

    public Socio(String nombre) {
        this.nombre = nombre;
    }

    public void prestarLibro(Libro libro) {
        librosPrestados.add(libro);
        historial.add(libro);
    }

    public void devolverLibro(Libro libro, int diasRetraso) {
        librosPrestados.remove(libro);
        if (diasRetraso > 0) {
            multa += diasRetraso * 50;
        }
    }

    public boolean puedePrestar() {
        return multa == 0;
    }

    public void pagarMulta() {
        multa = 0;
    }

    public List<Libro> getHistorial() {
        return historial;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return nombre + " (Multa: $" + multa + ")";
    }
}
