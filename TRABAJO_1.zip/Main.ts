public class Main {
    public static void main(String[] args) {
        Autor a1 = new Autor("Gabriel García Márquez", "Escritor colombiano", 1927);
        Libro l1 = new Libro("Cien Años de Soledad", "123", a1);
        Libro l2 = new Libro("El Amor en los Tiempos del Cólera", "456", a1);

        Socio s1 = new Socio("Juan");
        Socio s2 = new Socio("María");

        Biblioteca b = new Biblioteca();
        b.agregarLibro(l1);
        b.agregarLibro(l2);
        b.agregarSocio(s1);
        b.agregarSocio(s2);

        b.prestarLibro("Cien Años de Soledad", s1);
        b.prestarLibro("Cien Años de Soledad", s2); // reserva
        b.devolverLibro("Cien Años de Soledad", s1, 3); // genera multa y avisa a María

        b.recomendarLibros(s1);

        EventoBiblioteca ev = new EventoBiblioteca("Club de lectura", "10/09/2025");
        b.agregarEvento(ev);
        b.mostrarEventos();
    }
}
